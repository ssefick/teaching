vel_exp <- read.csv("experiment_velocity_time_series.csv")
library(ggplot2)
vel_exp$date <- as.Date(vel_exp$date)
plot_1 <- qplot(date, velocity, data = vel_exp, geom = "line", col = block)
plot_1 <- plot_1 + facet_wrap(~block)
source("publication_ggplot2_theme.R")
plot_1 <- plot_1 + publication()

pdf("Clark_Ex2.pdf", height = 20, width = 20)
plot_1
dev.off()

