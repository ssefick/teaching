The HW_5.sh is used to evaluate sequences using a reference genome with BLAST

The module needed for this script is blast+ and can be optained on ASC with the command
	$module load blast+

Documentation for this module can also be found on ASC

For this case three types of sequences were evaluated, mitochondrial, cytoplasmic, and nuclear.

This script blasts and compiles the results of each type with the reference.
You will make a database, link to the reference file and then compare the sequences of interest with BLAST
Basic sed, awk, grep, along with head, ls, and less can be used to compile the useful information.

