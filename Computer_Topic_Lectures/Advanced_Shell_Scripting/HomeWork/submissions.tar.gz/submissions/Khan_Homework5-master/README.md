# Khan_Homework5

The goal for using this shell script is to identify the number of hits in three different genomes(nucleus genome, Mitochondrial genome and Chloroplast genome) using multiple databases. It used the symbolic link to facilitate the database use. Important parts of the scripts are describe below.


Shebang line to read the binary file.

```#! /bin/bash/```

module load for blast+

```module load blast+/2.3.0```

Database preparation for subjects. `-in` option for input and `-dbtype` to specify the type of database. nucl=dna sequence . 

```mkblastdb makeblastdb -in ATcp.fasta -dbtype nucl```

Symbolic link the database to the Arabidopsis genome folder where the databases of the different chromosomes are ready to use. The symbolic link make the path smaller and easier to use in current directory.

```ln -s /apps/bio/unzipped/genomes/Arabidopsis_thaliana/ .```

blastn option was used for a single database match identification. `ATmt.fasta` for Mitochondrial genome matches, `ATcp.fasta` for Chloroplast genome matches and `ATchrV.fasta` chromosome V database hits. The `-outfmt 7` was used to get tabula format data, `-query` option used to input the `test.fasta` file, `-db` for database input, and `>` for output file instead of standard output.Later the Symbolic link database was tested too.

```
blastn -query test.fasta -db ATchrV.fasta -outfmt 7 >qtest_dbV.blastn.out
blastn -query test.fasta -db ATcp.fasta -outfmt 7 >qtest_dbcp.blastn.out
blastn -query test.fasta -db ATmt.fasta -outfmt 7 >qtest_dbmt.blastn.out
blastn -query test.fasta -db ./Arabidopsis_thaliana/CHR_I/NC_003070.gbk -outfmt 7 >qtest_dbI_classtime.blastn.out
```
To count the hits in the different genomes (nucleus genome(NT), Mitochondrial genome(MT) and Chloroplast genome(CP)) there was a long one liner used.

```
blastn -db "ATmt.fasta ATcp.fasta ATchrV.fasta ./Arabidopsis_thaliana/CHR_I/NC_003070.gbk Arabidopsis_thaliana/CHR_II/NC_003071.gbk Arabidopsis_thaliana/CHR_III/NC_003074.gbk Arabidopsis_thaliana/CHR_IV/NC_003075.gbk" -query test.fasta -outfmt 7 -evalue 0.00001 -max_target_seqs 1|egrep -v '^#' | sed 's/[[:space:]]1_\/home.*NC_[0-9]*[[:space:]]/\tNT\t/'| 
awk '{print $2,$1}' | sort | uniq |awk '{print $1}' | sort | uniq -c | sort -n > RawCounts.txt

less RawCounts.txt

exit
```
To understand each part of the one liner we will go step by step. First the blastn option of the blast+ used a combined database. `"databases"` option make the search in all the databases at a time. As an additional option of blastn `-evalue 0.00001` and `-max_target_seqs 1` used to specify the evalue and number of target sequence. 

The output was piped or tranferred to regular expression `egrep` to extract only the line which does not contain `#` in the begining. The Mitochondrial genome(MT) and Chloroplast genome(CP) were giving the output as directly in the MT and CP format respectively but the nucleus genome were showing specific genome. To make it simple `NT` regular expression `sed` was used.

In `sed` matched any space then `1_`. Then /home by using `\/home`,`.` represents the match to any character, `*`any number of times until `NC_`. Followed by digits 0-9 (`[0-9]*`) any number of times then any space. The whole match was replaced by `tabNTtab`.

```
sed 's/[[:space:]]1_\/home.*NC_[0-9]*[[:space:]]/\tNT\t/'
```
After the replacement of the genome information by NT the file is ready to count the number of hits. `awk` was used to print only column 2 and 1 then sorted it by `sort` and kept only unique entries by `uniq`. Later awk printed the column 1 which consist of MT,NT,CP. `uniq -c` count the number of occurrences and final `sort -n` did numeric sort. 

The output is transferred in `RawCounts.txt` file. 


@AUIntroBioinformatics





