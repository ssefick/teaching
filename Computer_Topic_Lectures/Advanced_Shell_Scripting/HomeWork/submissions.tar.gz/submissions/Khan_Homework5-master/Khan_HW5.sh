#########################
#! /bin/bash/ 
#########################


#########################
#module load
module load blast+
#########################

####################################################################
#Database Preparation 
#files should be in the current floder 

makeblastdb -in ATchrV.fasta -dbtype nucl  
makeblastdb -in ATcp.fasta -dbtype nucl
makeblastdb -in ATmt.fasta -dbtype nucl

#Symbolic Link to the existing database of Arabidopsis genome in the current directory

ln -s /apps/bio/unzipped/genomes/Arabidopsis_thaliana/ .

#less /apps/bio/unzipped/genomes/Arabidopsis_thaliana/CHR_I/

####################################################################


##############################################################################################
#Run the blastn option of the blast+ using single database
#For details please see	the readme

blastn -query test.fasta -db ATchrV.fasta -outfmt 7 >qtest_dbV.blastn.out
blastn -query test.fasta -db ATcp.fasta -outfmt 7 >qtest_dbcp.blastn.out
blastn -query test.fasta -db ATmt.fasta -outfmt 7 >qtest_dbmt.blastn.out
blastn -query test.fasta -db ./Arabidopsis_thaliana/ -outfmt 7 >qtest_dbI_classtime.blastn.out

#less qtest_dbI_classtime.blastn.out 
#less qtest_dbmt.blastn.out

###############################################################################################

#Count the hits for nucleus genome(NT), Mitochondrial genome(MT) and Chloroplast genome(CP)
#For details please see the readme 

blastn -db "ATmt.fasta ATcp.fasta ATchrV.fasta ./Arabidopsis_thaliana/CHR_I/NC_003070.gbk Arabidopsis_thaliana/CHR_II/NC_003071.gbk Arabidopsis_thaliana/CHR_III/NC_003074.gbk Arabidopsis_thaliana/CHR_IV/NC_003075.gbk" -query test.fasta -outfmt 7 -evalue 0.00001 -max_target_seqs 1| egrep -v '^#' | sed 's/[[:space:]]1_\/home.*NC_[0-9]*[[:space:]]/\tNT\t/'| awk '{print $1,$2}' | sort | uniq |awk '{print $2}' | sort | uniq -c | sort -n > RawCounts.txt

less RawCounts.txt 

################################################################################################

exit


