# ######################## 
#!/usr/bin/env sh
# ########################

# #####################
##Modules
module load blast+
# #####################

# ####################
# Commands
#copy files into working directory
cp ~/class_shared/GuestLectureII/ATcp.fasta ~/nathan_hall_lecture_2-21/
cp ~/class_shared/GuestLectureII/ATchrV.fasta ~/nathan_hall_lecture_2-21/
cp ~/class_shared/GuestLectureII/ATmt.fasta ~/nathan_hall_lecture_2-21/
cp ~/class_shared/GuestLectureII/test.fasta ~/nathan_hall_lecture_2-21/

#create database for project. (notice type is nuclear)
makeblastdb -in ATchrV.fasta -dbtype nucl

#use less, ls, and head at any time to view files
#less /apps/bio/unzipped/genomes/Arabidopsis_thaliana/README
#ls /apps/bio/unzipped/genomes/Arabidopsis_thaliana/CHR_I/

#make symbolic link of the reference genome
ln -s /apps/bio/unzipped/genomes/Arabidopsis_thaliana/ .

#consult module help page to view options and you can run "tests" to see which out formats you prefer
#blastn -help
#blastn -query test.fasta -db ATmt.fasta -outfmt 7 | less -S

#blast each sequence and create output files
blastn -query test.fasta -db ATmt.fasta -outfmt 7 > qtest_dbmt.blastn_out
blastn -query test.fasta -db ATcp.fasta -outfmt 7 > qtest_dbcp.blastn_out
blastn -query test.fasta -db Arabidopsis_thaliana/CHR_I/NC_003070.gbk -outfmt 7 > qtest_dbI.blastn_out

#look at output for specific locus
#grep "ATMG00020.1" qtest_dbI.blastn_out

#blast each kind of sequence, remove clunky names and compile hits into one file
blastn -db "ATcp.fasta ATmt.fasta ATchrV.fasta Arabidopsis_thaliana/CHR_I/NC_003070.gbk Arabidopsis_thaliana/CHR_II/NC_003071.gbk Arabidopsis_thaliana/CHR_III/NC_003074.gbk Arabidopsis_thaliana/CHR_IV/NC_003075.gbk" -query test.fasta -outfmt 7 -evalue 0.00001 -max_target_seqs 1 | egrep -v '^#' | sed 's/[[:space:]]1_\/home.*NC_[0-9]*[[:space:]]/\tNT\t/' | awk '{print$1,$2}' | sort | uniq | awk '{print $2}' | sort | uniq -c | sort -n > RawCounts.txt

#count number of 0 hits for each output
#grep -c '0 hits' qtest_dbI.blastn_out
#grep -c '0 hits' qtest_dbcp.blastn_out
#grep -c '0 hits' qtest_dbmt.blastn_out

#note number of loci that return no blast hits
NUM=$(blastn -db "ATcp.fasta ATmt.fasta ATchrV.fasta Arabidopsis_thaliana/CHR_I/NC_003070.gbk Arabidopsis_thaliana/CHR_II/NC_003071.gbk Arabidopsis_thaliana/CHR_III/NC_003074.gbk Arabidopsis_thaliana/CHR_IV/NC_003075.gbk" -query test.fasta -outfmt 7 -evalue 0.00001 -max_target_seqs 1 | grep -c ' 0 hits' ) && echo $NUM No_hits >> RawCounts.txt
# ##############
